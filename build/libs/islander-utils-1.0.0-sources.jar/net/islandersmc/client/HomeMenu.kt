package net.islandersmc.client

import net.minecraft.client.Minecraft
import net.minecraft.client.gui.GuiGraphicsExtractor
import net.minecraft.client.gui.components.Button
import net.minecraft.client.gui.screens.Screen
import net.minecraft.network.chat.Component

class HomeMenu : Screen(Component.literal("Teleport Menu")) {

    override fun init() {
        val buttonWidth = 200
        val buttonHeight = 20
        val x = (width - buttonWidth) / 2
        val y = height / 2 - 72
        //rtp button
        addRenderableWidget(
            Button.builder(Component.literal("Random Teleport")) { _ ->
                //action
                Minecraft.getInstance().player?.connection?.sendCommand(
                    "rtp"
                )
                onClose()
            }
                .bounds(x, y, buttonWidth, buttonHeight)
                .build()
        )
        //spawn button
        addRenderableWidget(
            Button.builder(Component.literal("Spawn")) { _ ->
                //action
                Minecraft.getInstance().player?.connection?.sendCommand(
                    "spawn"
                )
                onClose()
            }
                .bounds(x, y+ 24, buttonWidth, buttonHeight)
                .build()
        )
        //home button
        addRenderableWidget(
            Button.builder(Component.literal("Home")) { _ ->
                //action
                Minecraft.getInstance().player?.connection?.sendCommand(
                    "home home"
                )
                onClose()
            }
                .bounds(x, y+ 48, buttonWidth, buttonHeight)
                .build()
        )
        //claim button
        addRenderableWidget(
            Button.builder(Component.literal("Claim")) { _ ->
                //action
                Minecraft.getInstance().player?.connection?.sendCommand(
                    "hs home"
                )
                onClose()
            }
                .bounds(x, y+ 72, buttonWidth, buttonHeight)
                .build()
        )
        //bed button
        addRenderableWidget(
            Button.builder(Component.literal("Bed")) { _ ->
                //action
                Minecraft.getInstance().player?.connection?.sendCommand(
                    "home bed"
                )
                onClose()
            }
                .bounds(x, y+ 96, buttonWidth, buttonHeight)
                .build()
        )
        //close button ig
        addRenderableWidget(
            Button.builder(Component.literal("Close")) { _ ->
                //close menu
                onClose()
            }
                .bounds(x, y + 120, buttonWidth, buttonHeight)
                .build()
        )
    }

    override fun extractRenderState(
        graphics: GuiGraphicsExtractor,
        mouseX: Int,
        mouseY: Int,
        delta: Float
    ) {
        super.extractRenderState(graphics, mouseX, mouseY, delta)

        val heading = "Teleport Menu"

        graphics.text(
            font,
            heading,
            (width - font.width(heading)) /2,
            height /2 -96,
            0xFFFFFFFFF.toInt(),
            true
        )
    }
}